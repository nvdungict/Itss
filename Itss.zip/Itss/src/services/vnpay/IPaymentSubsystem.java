package services.vnpay;

public class IPaymentSubsystem {

}
