package services.vnpay;

public class PayRequestVNPay {

}
