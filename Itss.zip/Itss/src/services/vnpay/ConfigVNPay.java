package services.vnpay;

public class ConfigVNPay {

}
