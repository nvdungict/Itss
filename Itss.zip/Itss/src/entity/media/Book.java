package entity.media;

public class Book {

}
