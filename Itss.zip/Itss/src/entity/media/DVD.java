package entity.media;

public class DVD {

}
