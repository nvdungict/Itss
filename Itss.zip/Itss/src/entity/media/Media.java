package entity.media;

public class Media {

}
