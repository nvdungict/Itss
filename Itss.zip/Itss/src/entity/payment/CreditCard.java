package entity.payment;

public class CreditCard {

}
