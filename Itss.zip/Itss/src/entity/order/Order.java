package entity.order;

public class Order {

}
