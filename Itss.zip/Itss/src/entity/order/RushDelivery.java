package entity.order;

public class RushDelivery {

}
