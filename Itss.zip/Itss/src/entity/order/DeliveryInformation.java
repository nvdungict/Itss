package entity.order;

public class DeliveryInformation {

}
