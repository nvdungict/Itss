package entity.user;

public class User {

}
