package entity.cart;

public class Cart {

}
