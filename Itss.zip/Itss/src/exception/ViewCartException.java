package exception;

public class ViewCartException {

}
