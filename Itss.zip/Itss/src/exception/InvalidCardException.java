package exception;

public class InvalidCardException {

}
