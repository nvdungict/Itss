package exception;

public class PaymentException {

}
