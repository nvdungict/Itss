package exception;

public class PlaceOrderException {

}
