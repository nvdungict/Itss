package DAO;

public class IMediaDAO {

}
