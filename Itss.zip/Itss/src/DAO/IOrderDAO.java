package DAO;

public class IOrderDAO {

}
