package DAO;

public class ICartDAO {

}
