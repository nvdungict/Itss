package DAO;

public class IUserDAO {

}
