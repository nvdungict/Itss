package controller;

public class SearchController {

}
