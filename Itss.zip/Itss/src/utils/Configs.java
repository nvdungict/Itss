package utils;

public class Configs {

}
