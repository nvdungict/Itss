package utils;

public class DeliveryValidateInfor {

}
