package db;

public class AIMSDB {

}
