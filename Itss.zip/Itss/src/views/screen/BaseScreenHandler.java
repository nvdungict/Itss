package views.screen;

public class BaseScreenHandler {

}
