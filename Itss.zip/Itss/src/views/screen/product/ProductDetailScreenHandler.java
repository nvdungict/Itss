package views.screen.product;

public class ProductDetailScreenHandler {

}
