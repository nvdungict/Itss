package views.screen.product;

public class CreateProductHandler {

}
