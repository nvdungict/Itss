package views.screen.payment;

public class ResultScreenHandler {

}
